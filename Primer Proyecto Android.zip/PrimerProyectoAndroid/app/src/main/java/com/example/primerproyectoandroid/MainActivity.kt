package com.example.primerproyectoandroid

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doOnTextChanged
import com.example.primerproyectoandroid.modelo.Estudiante

class MainActivity : AppCompatActivity() {
    private var tvPromedio: TextView? = null
    private var botonCalcularPromedio: Button? = null
    private var etNota1: EditText? = null
    private var etNota2: EditText? = null
    private var etNota3: EditText? = null
    private var switchCalculoAutomatico: Switch? = null
    private var calcularAutomaticamente = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        switchCalculoAutomatico = findViewById<Switch>(R.id.switchCalcularAutomaticamente)
        botonCalcularPromedio = findViewById<Button>(R.id.btCalcularPromedio)
        etNota1 = findViewById<EditText>(R.id.etNota1)
        etNota2 = findViewById<EditText>(R.id.etNota2)
        etNota3 = findViewById<EditText>(R.id.etNota3)
        tvPromedio = findViewById<TextView>(R.id.tvPromedio)

        botonCalcularPromedio?.setOnClickListener {
            mostrarPromedio()
        }

        val textWatcher:TextWatcher = object:TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if( calcularAutomaticamente) {
                    mostrarPromedio()
                }
            }

        }

        etNota1?.addTextChangedListener(textWatcher)
        etNota2?.addTextChangedListener(textWatcher)
        etNota3?.addTextChangedListener(textWatcher)

        switchCalculoAutomatico?.setOnCheckedChangeListener { buttonView, isChecked ->
            calcularAutomaticamente = isChecked

        }
    }


    private fun mostrarPromedio() {
        val estudiante = Estudiante()
        val nota1 = etNota1?.text.toString().toFloatOrNull() ?: 1.0f
        val nota2 = etNota2?.text.toString().toFloatOrNull() ?: 1.0f
        val nota3 = etNota3?.text.toString().toFloatOrNull() ?: 1.0f

        estudiante.agregarNota(nota1)
        estudiante.agregarNota(nota2)
        estudiante.agregarNota(nota3)

        val promedio = estudiante.calcularPromedio()
        tvPromedio?.text = promedio.toString()
    }
}