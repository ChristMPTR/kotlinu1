package com.example.primerproyectoandroid.modelo

class Estudiante(val notas: MutableList<Float> = mutableListOf<Float>()) {
    fun  agregarNota(nota:Float) {
        notas.add(nota)
    }
    fun calcularPromedio(): Float {
        if( notas.size === 0) return 1.0f
        val sumaNotas = notas.sum()
        return sumaNotas / notas.size
    }
}
fun main() {
    val estudiante = Estudiante()
    estudiante.agregarNota(1.0f)
    estudiante.agregarNota(7.0f)
    println("El promedio es: "+estudiante.calcularPromedio())
}