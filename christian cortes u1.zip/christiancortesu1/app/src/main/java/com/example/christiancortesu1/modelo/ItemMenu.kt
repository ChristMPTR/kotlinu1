package com.example.model

data class ItemMenu(
    val nombre: String,
    val precio: Int
)
